//
//  ViewController.swift
//  swag-net
//
//  Created by Pavel Bashkirev on 12.02.2021.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

